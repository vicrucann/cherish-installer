Cherish: Tool for Cultural Heritage Data Organization by using Image Manipulation and 3D Sketching

For user manual, go to: http://vicrucann.github.io/cherish/